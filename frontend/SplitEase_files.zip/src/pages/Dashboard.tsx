import  { useState, useEffect } from 'react';
 
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import Navbar from '../components/Navbar';
import { Plus, Users } from 'lucide-react';

interface Group {
  id: string;
  name: string;
  memberCount: number;
}

export default function Dashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [groups, setGroups] = useState<Group[]>([]);
  const [showCreateGroup, setShowCreateGroup] = useState(false);
  const [groupName, setGroupName] = useState('');

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    if (!user.isSubscribed) {
      navigate('/pricing');
      return;
    }
  }, [user, navigate]);

  const createGroup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!groupName.trim()) return;
    
    const newGroup: Group = {
      id: Date.now().toString(),
      name: groupName,
      memberCount: 1
    };
    
    setGroups([...groups, newGroup]);
    setGroupName('');
    setShowCreateGroup(false);
  };

  if (!user?.isSubscribed) return null;

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Your Groups</h1>
          <button
            onClick={() => setShowCreateGroup(true)}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2 hover:bg-blue-700"
          >
            <Plus className="h-5 w-5" />
            <span>Create Group</span>
          </button>
        </div>

        {showCreateGroup && (
          <div className="bg-white p-6 rounded-lg shadow-md mb-8">
            <h3 className="text-lg font-semibold mb-4">Create New Group</h3>
            <form onSubmit={createGroup} className="flex space-x-4">
              <input
                type="text"
                value={groupName}
                onChange={(e) => setGroupName(e.target.value)}
                placeholder="Group name"
                className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
              <button
                type="submit"
                className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700"
              >
                Create
              </button>
              <button
                type="button"
                onClick={() => setShowCreateGroup(false)}
                className="bg-gray-300 text-gray-700 px-6 py-2 rounded-md hover:bg-gray-400"
              >
                Cancel
              </button>
            </form>
          </div>
        )}

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {groups.map((group) => (
            <div
              key={group.id}
              className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg cursor-pointer"
              onClick={() => navigate(`/group/${group.id}`)}
            >
              <h3 className="text-xl font-semibold mb-2">{group.name}</h3>
              <div className="flex items-center text-gray-600">
                <Users className="h-4 w-4 mr-2" />
                <span>{group.memberCount} member{group.memberCount !== 1 ? 's' : ''}</span>
              </div>
            </div>
          ))}
        </div>

        {groups.length === 0 && (
          <div className="text-center py-12">
            <h3 className="text-xl font-semibold text-gray-600 mb-2">No groups yet</h3>
            <p className="text-gray-500">Create your first group to start splitting expenses!</p>
          </div>
        )}
      </div>
    </div>
  );
}
 