import  { useState, useEffect } from 'react';
 
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import Navbar from '../components/Navbar';
import { Plus, Calendar, DollarSign } from 'lucide-react';

interface Expense {
  id: string;
  description: string;
  amount: number;
  payer: string;
  date: string;
  participants: string[];
}

export default function Group() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [showAddExpense, setShowAddExpense] = useState(false);
  const [newExpense, setNewExpense] = useState({
    description: '',
    amount: '',
    payer: user?.name || '',
    participants: [user?.name || '']
  });

  useEffect(() => {
    if (!user?.isSubscribed) {
      navigate('/pricing');
    }
  }, [user, navigate]);

  const addExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newExpense.description || !newExpense.amount) return;

    const expense: Expense = {
      id: Date.now().toString(),
      description: newExpense.description,
      amount: parseFloat(newExpense.amount),
      payer: newExpense.payer,
      date: new Date().toISOString().split('T')[0],
      participants: newExpense.participants
    };

    setExpenses([...expenses, expense]);
    setNewExpense({
      description: '',
      amount: '',
      payer: user?.name || '',
      participants: [user?.name || '']
    });
    setShowAddExpense(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Group Expenses</h1>
          <button
            onClick={() => setShowAddExpense(true)}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2 hover:bg-blue-700"
          >
            <Plus className="h-5 w-5" />
            <span>Add Expense</span>
          </button>
        </div>

        {showAddExpense && (
          <div className="bg-white p-6 rounded-lg shadow-md mb-8">
            <h3 className="text-lg font-semibold mb-4">Add New Expense</h3>
            <form onSubmit={addExpense} className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="Description"
                  value={newExpense.description}
                  onChange={(e) => setNewExpense({...newExpense, description: e.target.value})}
                  className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
                <input
                  type="number"
                  step="0.01"
                  placeholder="Amount"
                  value={newExpense.amount}
                  onChange={(e) => setNewExpense({...newExpense, amount: e.target.value})}
                  className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div className="flex space-x-4">
                <button
                  type="submit"
                  className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700"
                >
                  Add Expense
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddExpense(false)}
                  className="bg-gray-300 text-gray-700 px-6 py-2 rounded-md hover:bg-gray-400"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        )}

               <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h3 className="text-lg font-semibold mb-4">Group Summary</h3>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">
                ${expenses.reduce((sum, exp) => sum + exp.amount, 0).toFixed(2)}
              </div>
              <div className="text-sm text-gray-600">Total Expenses</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{expenses.length}</div>
              <div className="text-sm text-gray-600">Transactions</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">
                ${(expenses.reduce((sum, exp) => sum + exp.amount, 0) / Math.max(1, new Set(expenses.map(e => e.payer)).size)).toFixed(2)}
              </div>
              <div className="text-sm text-gray-600">Per Person</div>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          {expenses.map((expense) => (
            <div key={expense.id} className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-lg font-semibold">{expense.description}</h3>
                  <div className="flex items-center text-gray-600 mt-2">
                    <DollarSign className="h-4 w-4 mr-1" />
                    <span className="font-medium">${expense.amount.toFixed(2)}</span>
                    <span className="mx-2">•</span>
                    <span>Paid by {expense.payer}</span>
                  </div>
                  <div className="text-sm text-gray-500 mt-1">
                    Split among {expense.participants.length} member{expense.participants.length !== 1 ? 's' : ''}
                  </div>
                </div>
                <div className="flex items-center text-gray-500">
                  <Calendar className="h-4 w-4 mr-1" />
                  <span>{expense.date}</span>
                </div>
              </div>
            </div>
          ))}
        </div> 

        {expenses.length === 0 && (
          <div className="text-center py-12">
            <h3 className="text-xl font-semibold text-gray-600 mb-2">No expenses yet</h3>
            <p className="text-gray-500">Add your first expense to start tracking!</p>
          </div>
        )}
      </div>
    </div>
  );
}
 