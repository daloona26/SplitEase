import  { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import Navbar from '../components/Navbar';
import { CheckCircle } from 'lucide-react';
import { PayPalScriptProvider, PayPalButtons } from '@paypal/react-paypal-js';

export  default function Pricing() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<'monthly' | 'yearly'>('monthly');

  const paypalOptions = {
    clientId: "AcSAJuZxJ7tO-4vnuKHk2ION929C9QQjGjiw-ThMCSDTRNQoYhOPfKzFGjmC3O70eRUXFkixKwmPhnah",
    currency: "USD",
    intent: "capture"
  };

  const createOrder = (data: any, actions: any) => {
    const amount = selectedPlan === 'monthly' ? "5.00" : "50.00";
    const description = selectedPlan === 'monthly' 
      ? "SplitEase Pro Monthly Subscription" 
      : "SplitEase Pro Yearly Subscription";
    
    return actions.order.create({
      purchase_units: [{
        amount: {
          value: amount,
          currency_code: "USD"
        },
        description
      }]
    });
  }; 

  const onApprove = async (data: any, actions: any) => {
    setLoading(true);
    try {
      const order = await actions.order.capture();
      if (order.status === "COMPLETED" && user) {
        const updatedUser = { ...user, isSubscribed: true };
        localStorage.setItem('user', JSON.stringify(updatedUser));
        navigate('/dashboard');
      }
    } catch (error) {
      console.error('Payment error:', error);
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    navigate('/login');
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="max-w-4xl mx-auto px-4 py-16">
               <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Simple, Transparent Pricing
          </h1>
          <p className="text-xl text-gray-600">
            Perfect for roommates, couples, and travelers splitting costs
          </p>
        </div>

        <div className="flex justify-center mb-8">
          <div className="bg-gray-100 p-1 rounded-lg flex">
            <button
              onClick={() => setSelectedPlan('monthly')}
              className={`px-6 py-2 rounded-md font-medium ${
                selectedPlan === 'monthly'
                  ? 'bg-white text-blue-600 shadow-sm'
                  : 'text-gray-600'
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setSelectedPlan('yearly')}
              className={`px-6 py-2 rounded-md font-medium ${
                selectedPlan === 'yearly'
                  ? 'bg-white text-blue-600 shadow-sm'
                  : 'text-gray-600'
              }`}
            >
              Yearly
            </button>
          </div>
        </div>

        <div className="max-w-md mx-auto">
          <div className="bg-white rounded-2xl shadow-xl p-8 border-2 border-blue-200">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold text-gray-900">SplitEase Pro</h3>
              <div className="mt-4">
                <span className="text-5xl font-bold text-blue-600">
                  ${selectedPlan === 'monthly' ? '5' : '50'}
                </span>
                <span className="text-gray-600">
                  /{selectedPlan === 'monthly' ? 'month' : 'year'}
                </span>
              </div>
              {selectedPlan === 'yearly' && (
                <div className="text-sm text-green-600 font-medium mt-2">
                  Save $10 per year!
                </div>
              )}
            </div> 

                       <ul className="space-y-4 mb-8">
              {[
                'Create unlimited shared groups',
                'Log and track all expenses',
                'Automatic debt calculations',
                'Split costs among group members',
                'View who owes whom',
                'Perfect for roommates & travelers',
                'Secure data storage',
                'Mobile-friendly interface'
              ].map((feature, index) => (
                <li key={index} className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span className="text-gray-700">{feature}</span>
                </li>
              ))} 
            </ul>

            {user?.isSubscribed ? (
              <div className="w-full bg-green-100 text-green-800 py-3 px-6 rounded-lg font-semibold text-center">
                Already Subscribed
              </div>
            ) : (
              <div className="w-full">
                <PayPalScriptProvider options={paypalOptions}>
                  <PayPalButtons
                    createOrder={createOrder}
                    onApprove={onApprove}
                    onError={(err) => console.error('PayPal error:', err)}
                    style={{
                      layout: "vertical",
                      color: "blue",
                      shape: "rect",
                      label: "pay"
                    }}
                  />
                </PayPalScriptProvider>
              </div>
            )}

            <p className="text-sm text-gray-500 text-center mt-4">
              Secure payment via PayPal. Cancel anytime.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
 