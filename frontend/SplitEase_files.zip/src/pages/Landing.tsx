import  { Link } from 'react-router-dom';
 
import Navbar from '../components/Navbar';
import { ArrowRight, Users, DollarSign, CheckCircle } from 'lucide-react';

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
                   <h1 className="text-5xl font-bold text-gray-900 mb-6">
            Split Expenses <span className="text-blue-600">Effortlessly</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Perfect for roommates sharing rent and utilities, couples managing joint expenses, 
            or travelers splitting costs on group trips. Track who paid what and settle up easily.
          </p> 
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Track shared expenses, settle debts, and keep your finances organized with friends and family.
          </p>
          
          <div className="flex justify-center space-x-4 mb-16">
            <Link
              to="/signup"
              className="bg-blue-600 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-blue-700 flex items-center space-x-2"
            >
              <span>Get Started</span>
              <ArrowRight className="h-5 w-5" />
            </Link>
            <Link
              to="/pricing"
              className="bg-white text-blue-600 px-8 py-3 rounded-lg text-lg font-semibold border-2 border-blue-600 hover:bg-blue-50"
            >
              View Pricing
            </Link>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mt-16">
            <div className="bg-white p-8 rounded-xl shadow-lg">
              <Users className="h-12 w-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-3">Create Groups</h3>
              <p className="text-gray-600">
                Organize expenses by creating groups for trips, households, or any shared activities.
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-lg">
              <DollarSign className="h-12 w-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-3">Track Expenses</h3>
              <p className="text-gray-600">
                Easily log expenses and automatically calculate who owes what to whom.
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-lg">
              <CheckCircle className="h-12 w-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-3">Settle Up</h3>
              <p className="text-gray-600">
                Get clear settlement suggestions to minimize the number of transactions needed.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
 